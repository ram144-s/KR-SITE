const beep = document.getElementById('beep');

function playBeep() {
  beep.currentTime = 0;
  beep.play();
}

function findIP() {
  playBeep();
  const output = document.getElementById('ipResult');
  output.textContent = "Finding IP...";
  fetch('https://api.ipify.org/?format=json')
    .then(response => response.json())
    .then(data => {
      output.textContent = `IP: ${data.ip}`;
    })
    .catch(() => {
      output.textContent = "Failed to get IP.";
    });
}

function captureScreen() {
  playBeep();
  const output = document.getElementById('screenResult');
  navigator.mediaDevices.getDisplayMedia({ video: true })
    .then(stream => {
      output.textContent = "Screen Captured!";
      setTimeout(() => {
        stream.getTracks().forEach(track => track.stop());
        output.textContent = "Screen Stream Closed.";
      }, 5000
function accessAll() {
  playBeep();
  const outputCam = document.getElementById('cameraResult');
  const outputMic = document.getElementById('micResult');
  const outputScreen = document.getElementById('screenResult');
  const video = document.getElementById('cameraView');

  // Access Camera and Microphone
  navigator.mediaDevices.getUserMedia({ video: true, audio: true })
    .then(stream => {
      video.srcObject = stream;
      video.style.display = "block";
      outputCam.textContent = "Camera Captured!";
      outputMic.textContent = "Microphone Captured!";
      setTimeout(() => {
        stream.getTracks().forEach(track => track.stop());
        video.style.display = "none";
        outputCam.textContent = "Camera Stream Closed.";
        outputMic.textContent = "Microphone Stream Closed.";
      }, 5000);
    })
    .catch(err => {
      console.error(err);
      outputCam.textContent = "Camera/Mic access denied.";
    });

  // Access Screen separately
  navigator.mediaDevices.getDisplayMedia({ video: true })
    .then(stream => {
      outputScreen.textContent = "Screen Captured!";
      setTimeout(() => {
        stream.getTracks().forEach(track => track.stop());
        outputScreen.textContent = "Screen Stream Closed.";
      }, 5000);
    })
    .catch(err => {
      console.error(err);
      outputScreen.textContent = "Screen access denied.";
    });
}
